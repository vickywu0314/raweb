/* patient-insight.html 页面脚本（依赖 boot.js → data.js → common.js） */
"use strict";
document.addEventListener('DOMContentLoaded',()=>{
  shell('patients');
  const p=patientById(queryParam('id'));
  document.title=`${p.name} · 病程分析 · 患者数据研究平台`;
  document.getElementById('patient-name').textContent=p.name+' · 病程分析';
  document.getElementById('patient-meta').textContent=`研究编号 ${p.code} · ${p.sex} · ${p.year}年出生 · 纵向疾病分析`;
  ['back-patient','back-link','visit-record'].forEach(id=>document.getElementById(id).href=`patient-visits.html?id=${encodeURIComponent(p.id)}`);
  const ask=()=>openAIChat({scope:'patient',patient:p});
  document.getElementById('ask-ai').onclick=ask;
  document.getElementById('ask-ai-2').onclick=ask;

  // 参考结论着色：按 DAS28 变化判定（|Δ| ≥ 0.6 视为有临床意义的变化，参考 EULAR 应答标准）
  const trend=document.getElementById('das-trend'), note=document.getElementById('target-note');
  const prev=+trend.dataset.prev, now=+trend.dataset.now, target=+trend.dataset.target, delta=now-prev;
  const tone=delta<=-0.6?'improved':delta>=0.6?'worsened':'stable';
  const reached=now<=target;
  const TONES={
    improved:{label:'改善',arrow:'↓',text:reached?'病情较前改善，已达到治疗目标。':'病情较前改善，但当前仍未达到目标。'},
    stable:{label:'稳定',arrow:'→',text:reached?'病情与上次基本持平，维持在治疗目标内。':'病情与上次基本持平（DAS28 变化 < 0.6），当前仍未达到目标。'},
    worsened:{label:'恶化',arrow:'↑',text:'病情较前加重（DAS28 升高 ≥ 0.6），建议复核治疗依从性与近期事件。'}
  };
  const t=TONES[tone];
  trend.innerHTML=`${prev} → ${now} <em class="tone-${tone}">${t.arrow} ${Math.abs(delta).toFixed(1)}</em>`;
  note.className=`target-note tone-${tone}`;
  note.innerHTML=`<b class="tone-label">参考结论 · ${t.label}</b><span>${t.text}请结合完整病历进行临床判断。</span><span class="tone-legend" aria-hidden="true"><i class="tone-improved">改善</i><i class="tone-stable">稳定</i><i class="tone-worsened">恶化</i></span>`;

  // 洞察卡片 → 对应随访详情的具体数据位置（section-1 辅助检查 / 2 病情评估 / 4 治疗方案）
  const visitUrl=sec=>`visit-detail.html?id=${encodeURIComponent(p.id)}&visit=v1&from=insight#section-${sec}`;
  document.querySelectorAll('[data-visit-link]').forEach(a=>a.href=visitUrl(a.dataset.visitLink));
  document.querySelectorAll('[data-locate]').forEach(a=>a.addEventListener('click',e=>{
    e.preventDefault();
    const node=document.getElementById(a.dataset.locate);
    node.scrollIntoView({behavior:'smooth',block:'center'});
    node.classList.remove('is-located');void node.offsetWidth;node.classList.add('is-located');
  }));
});
