/* visit-create.html 页面脚本（依赖 boot.js → data.js → common.js → shared/case-form.js） */
"use strict";
document.addEventListener('DOMContentLoaded',()=>{
  shell('patients');
  const p=patientById(queryParam('id'));
  const nth=(p.visits||0)+1;
  const back=`patient-visits.html?id=${encodeURIComponent(p.id)}`;
  document.title=`${p.name} · 新增随访 · 患者数据研究平台`;
  document.querySelectorAll('.js-back-visits').forEach(a=>a.href=back);
  document.getElementById('visit-title').textContent=`新增随访 · ${p.name}`;
  document.getElementById('visit-sub').textContent=`研究编号 ${p.code} · 第 ${nth} 次随访 · 基本信息沿用患者档案，仅录入本次随访内容；未完成内容可暂存后补。`;

  // 基本信息：只读展示（身份证号、手机号脱敏）
  const mask=(v,keep)=>v?v.slice(0,keep)+'****'+v.slice(-4):'未提供';
  const rows=[['患者姓名',p.name],['性别',p.sex],['出生年份',`${p.year} 年`],['民族',p.ethnicity],['婚史',p.maritalStatus],
    ['患者手机号',mask(p.phone,3)],['患者身份证号',mask(p.identityNo,6)],['研究编号',p.code],['ID号',p.id],['随访观察起始',p.last||'未提供'],['身高 (cm)','未提供'],['体重 (kg)','未提供']];
  document.getElementById('basic-readonly').innerHTML=rows.map(([k,v])=>`<div><span>${k}</span><b>${escapeHTML(v||'未提供')}</b></div>`).join('');

  // 本次随访时间默认今天
  const vd=document.querySelector('[name="visitDate"]'); if(vd&&!vd.value) vd.value=new Date().toISOString().slice(0,10);

  // 打开时默认展开第一个可编辑模块
  document.getElementById('basic').open=false;
  const first=document.getElementById('history'); if(first) first.open=true;

  initCaseForm({draftMsg:'随访草稿已暂存（前端演示）',submitMsg:`第 ${nth} 次随访已保存（前端演示），即将返回患者详情`,afterSubmit:()=>location.href=back});
});
