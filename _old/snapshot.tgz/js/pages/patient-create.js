/* patient-create.html 页面脚本（依赖 boot.js → data.js → common.js → shared/case-form.js） */
"use strict";
document.addEventListener('DOMContentLoaded',()=>{
  shell('patients');
  initCaseForm({draftMsg:'草稿已暂存（前端演示）',submitMsg:'患者建档已保存（前端演示）'});
});
