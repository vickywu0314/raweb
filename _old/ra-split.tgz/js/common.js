"use strict";
const $=(s)=>document.querySelector(s);
const escapeHTML=(v)=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const icon=(n,c="")=>`<img src="img/${n}.svg" alt="" class="${c}">`;
const badge=(t,v="")=>`<span class="badge ${v}">${escapeHTML(t)}</span>`;
const patients=INITIAL_PATIENTS.map(p=>({...p}));
function patientById(id){return patients.find(p=>p.id===id)||patients[0]}
function followupStatus(p){if(p.lost)return{label:"已脱落",tone:"danger"};if(!p.visits)return{label:"待首次随访",tone:"neutral"};if(p.due)return{label:"近期需随访",tone:"warning"};return{label:"随访中",tone:"success"}}
function queryParam(n){return new URLSearchParams(location.search).get(n)}
const NAV_ICONS={
 overview:'<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
 dashboard:'<path d="M4 20h16"/><path d="M7 16v-5"/><path d="M12 16V7"/><path d="M17 16v-8"/>',
 patients:'<circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5"/><path d="M15.5 5.2a3 3 0 0 1 0 5.6"/><path d="M17.5 14.2c1.6.6 2.7 2.2 3 4.8"/>',
 followups:'<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/><path d="m9 15 2 2 4-4"/>',
 quality:'<path d="M12 3 5 6v5c0 4.4 2.9 8.3 7 9.5 4.1-1.2 7-5.1 7-9.5V6l-7-3Z"/><path d="m9 12 2 2 4-4"/>',
 ai:'<path d="M12 4.5 13.6 9l4.4 1.6-4.4 1.6L12 16.7l-1.6-4.5L6 10.6 10.4 9 12 4.5Z"/><path d="M18.5 3.5v3M17 5h3M6 16.5v3M4.5 18h3"/>',
 guideData:'<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4.5h6v2.5H9z"/><path d="M9 12h6M9 16h4"/>',
 learning:'<path d="M4 5.5C6.5 4.3 9.3 4.3 12 6c2.7-1.7 5.5-1.7 8-.5V19c-2.5-1.2-5.3-1.2-8 .5-2.7-1.7-5.5-1.7-8-.5V5.5Z"/><path d="M12 6v13.5"/>',
 help:'<circle cx="12" cy="12" r="8.5"/><path d="M9.6 9.5a2.5 2.5 0 1 1 3.4 2.3c-.6.3-1 .8-1 1.5v.4"/><path d="M12 16.8v.2"/>'
};
const navIcon=n=>`<svg class="nav-svg" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${NAV_ICONS[n]}</svg>`;
const STUDIES=[
 {code:'RA',name:'类风湿关节炎',en:'Rheumatoid Arthritis',ready:true,patients:128,abnormal:34},
 {code:'AS',name:'强直性脊柱炎',en:'Ankylosing Spondylitis'},
 {code:'SS',name:'系统性硬化症',en:'Systemic Sclerosis'},
 {code:'RA-ILD',name:'类风湿关节炎相关间质性肺病',en:'RA-associated Interstitial Lung Disease'},
 {code:'RA-MS',name:'类风湿关节炎肌少症',en:'RA & Sarcopenia'},
 {code:'FM',name:'纤维肌痛',en:'Fibromyalgia'}
];
function shell(active){
 const sidebar=document.querySelector('.sidebar');
 document.querySelectorAll('.header-knowledge-links,.header-study').forEach(el=>el.remove());
 if(sidebar){
   const cur=STUDIES[0];
   const studyItems=STUDIES.map(st=>st.ready
     ?`<a class="study-item is-current" href="projects.html" role="menuitem" aria-current="true"><span class="study-code">${st.code}</span><span class="study-text"><b>${st.code} ${st.name}</b><small>${st.en}</small><em class="study-meta"><i>${st.patients}</i> 患者 · <i>${st.abnormal}</i> 异常检验</em></span><span class="study-state ready">已接入</span></a>`
     :`<div class="study-item is-pending" role="menuitem" aria-disabled="true" title="该研究库尚未接入，暂不可进入"><span class="study-code">${st.code}</span><span class="study-text"><b>${st.code} ${st.name}</b><small>${st.en}</small></span><span class="study-state">待接入</span></div>`).join('');
   const item=(key,href,ic,label,count)=>`<a class="nav-item" data-nav="${key}" href="${href}">${navIcon(ic)}<span class="nav-text">${label}</span>${count?`<span class="nav-count">${count}</span>`:''}</a>`;
   sidebar.innerHTML=`<div class="project-context" id="project-context"><button type="button" id="project-switch" aria-haspopup="true" aria-expanded="false" aria-controls="project-menu"><span class="pc-code">${cur.code}</span><span class="pc-text"><b>${cur.name}</b><small><i class="pc-dot"></i>研究库已接入</small></span><svg class="pc-chevron" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m7 10 5 5 5-5"/></svg></button><div class="project-menu" id="project-menu" role="menu" aria-label="研究数据平台"><div class="project-menu-head"><b>研究数据平台</b><span>1 个已接入 · ${STUDIES.length-1} 个待接入</span></div><div class="project-menu-list">${studyItems}</div><p class="project-menu-foot">更多病种研究库将陆续接入，接入后可在此直接切换，工作台功能一致复用。</p></div></div><nav aria-label="主导航"><p class="nav-label">概览</p><div class="sidebar-nav-group">${item('projects','projects.html','overview','项目总览')}${item('dashboard','dashboard.html','dashboard','数据看板')}</div><p class="nav-label">研究执行</p><div class="sidebar-nav-group">${item('patients','patients.html','patients','患者管理')}${item('followups','followups.html','followups','随访管理')}${item('quality','data-quality.html','quality','数据质控')}</div><p class="nav-label">智能分析</p><div class="sidebar-nav-group">${item('ai','ai-analysis.html','ai','AI 智能分析')}</div><p class="nav-label">知识与规范</p><div class="sidebar-nav-group">${item('data-guide','data-guide.html','guideData','数据采集规范')}${item('learning','learning-center.html','learning','学习中心')}</div></nav><div class="sidebar-footer-nav">${item('guide','system-guide.html','help','使用指南')}</div>`;
   const act=sidebar.querySelector(`[data-nav="${active}"]`);
   if(act){act.classList.add('active');act.setAttribute('aria-current','page');}
   const ctx=sidebar.querySelector('#project-context');
   const sw=sidebar.querySelector('#project-switch');
   const setOpen=o=>{ctx.classList.toggle('open',o);sw.setAttribute('aria-expanded',String(o));};
   sw.addEventListener('click',e=>{e.stopPropagation();setOpen(!ctx.classList.contains('open'));});
   document.addEventListener('click',e=>{if(!ctx.contains(e.target))setOpen(false);});
   document.addEventListener('keydown',e=>{if(e.key==='Escape'&&ctx.classList.contains('open')){setOpen(false);sw.focus();}});
   sidebar.querySelectorAll('.study-item.is-pending').forEach(el=>el.addEventListener('click',()=>{el.classList.remove('nudge');void el.offsetWidth;el.classList.add('nudge');}));
 }
 const map={dashboard:'dashboard.html',patients:'patients.html',projects:'projects.html',followups:'followups.html',quality:'data-quality.html',ai:'ai-analysis.html'};
 document.querySelectorAll('[data-home]').forEach(a=>a.href=map[active]||'patients.html');
}

function demoVisits(p){
 const base={id:'v1',type:p.visits===1?'基线访视':'常规随访',date:p.last||'2026-09-08',method:'门诊随访',doctor:'陈医生',status:'completed',summary:'患者一般情况稳定，按计划完成本次随访。',dropout:!!p.lost,dropoutReasons:p.lost?['失访']:[]};
 return [base,{id:'v0',type:'基线访视',date:'2026-03-12',method:'门诊随访',doctor:'陈医生',status:'completed',summary:'完成基线资料采集。',dropout:false,dropoutReasons:[]}].filter((v,i)=>i===0||p.visits>1);
}
function downloadCase(p,v){const text=`RA 随诊病例（演示）\n患者：${p.name}\n患者ID：${p.id}\n研究编号：${p.code}\n访视：${v? v.type+' '+v.date:'全部随访记录'}\n\n当前为前端演示文件，真实病例下载需接入后端文档接口。`;const u=URL.createObjectURL(new Blob([text],{type:'text/plain;charset=utf-8'}));const a=document.createElement('a');a.href=u;a.download=`${p.name}-${v?v.date:'随诊病例'}.txt`;a.click();setTimeout(()=>URL.revokeObjectURL(u),500)}

// v23 contextual AI assistant drawer (front-end demo)
window.openAIChat=function(opts={}){
  const scope=opts.scope||'patient';
  const patient=opts.patient||{};
  const visit=opts.visit||null;
  let drawer=document.getElementById('ai-assistant-drawer');
  if(!drawer){
    const backdrop=document.createElement('div');backdrop.id='ai-drawer-backdrop';backdrop.className='ai-drawer-backdrop';document.body.appendChild(backdrop);
    drawer=document.createElement('aside');drawer.id='ai-assistant-drawer';drawer.className='ai-drawer';drawer.setAttribute('aria-label','AI 病情助手');
    drawer.innerHTML=`<div class="ai-drawer-head"><div class="ai-drawer-title"><span class="ai-drawer-title-mark">AI</span><span><strong>AI 病情助手</strong><small>基于当前患者研究数据对话</small></span></div><div class="ai-drawer-tools"><button class="ai-icon-btn" id="ai-drawer-expand" title="展开">↔</button><button class="ai-icon-btn" id="ai-drawer-close" title="关闭">×</button></div></div><div class="ai-context" id="ai-context"></div><div class="ai-chat" id="ai-chat"></div><div class="ai-compose"><div class="ai-compose-box"><textarea id="ai-input" rows="1" placeholder="针对当前患者病情提问……"></textarea><button class="ai-send" id="ai-send">发送</button></div><div class="ai-disclaimer">AI 内容基于当前研究数据生成，仅供临床参考，请结合实际情况判断。</div></div>`;
    document.body.appendChild(drawer);
    backdrop.onclick=()=>window.closeAIChat();
    drawer.querySelector('#ai-drawer-close').onclick=()=>window.closeAIChat();
    drawer.querySelector('#ai-drawer-expand').onclick=()=>{drawer.classList.toggle('wide');document.body.classList.toggle('ai-drawer-wide',drawer.classList.contains('wide'));drawer.querySelector('#ai-drawer-expand').textContent=drawer.classList.contains('wide')?'↔':'↔';};
    drawer.querySelector('#ai-input').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();drawer.querySelector('#ai-send').click();}});
  }
  drawer._ctx={scope,patient,visit};
  const context=drawer.querySelector('#ai-context');
  const visitText=visit?`${visit.date||''} ${visit.type||'本次访视'}`:'全部随访记录';
  context.innerHTML=`<strong>当前患者：</strong>${escapeHTML(patient.name||'当前患者')} <span class="ai-context-badge">${scope==='visit'?'单次访视':'患者全程'}</span><br><strong>当前上下文：</strong>${escapeHTML(visitText)}`;
  const chat=drawer.querySelector('#ai-chat');
  const suggestions=scope==='visit'?['总结本次访视需要关注的问题','哪些检查指标异常？','本次治疗方案有什么变化？']:['总结患者近期病情变化','哪些指标持续异常？','治疗方案历次如何调整？'];
  chat.innerHTML=`<div class="ai-msg assistant"><span class="ai-msg-label">AI 病情助手</span>我已载入${escapeHTML(patient.name||'该患者')}的${scope==='visit'?'本次访视及必要历史对照':'基础资料与历次随访'}。你可以一边查看左侧病历，一边针对病情继续提问。<div class="ai-suggestions">${suggestions.map(x=>`<button class="ai-suggestion">${escapeHTML(x)}</button>`).join('')}</div></div>`;
  chat.querySelectorAll('.ai-suggestion').forEach(b=>b.onclick=()=>{drawer.querySelector('#ai-input').value=b.textContent;drawer.querySelector('#ai-send').click();});
  drawer.querySelector('#ai-send').onclick=()=>{
    const input=drawer.querySelector('#ai-input');const q=input.value.trim();if(!q)return;input.value='';
    chat.insertAdjacentHTML('beforeend',`<div class="ai-msg user"><span class="ai-msg-label">医生</span>${escapeHTML(q)}</div>`);chat.scrollTop=chat.scrollHeight;
    const loading=document.createElement('div');loading.className='ai-msg assistant';loading.innerHTML='<span class="ai-msg-label">AI 病情助手</span>正在结合当前患者数据分析…';chat.appendChild(loading);chat.scrollTop=chat.scrollHeight;
    setTimeout(()=>{loading.innerHTML=`<span class="ai-msg-label">AI 病情助手</span>${scope==='visit'?'从当前访视看，建议优先关注已标记的异常检查指标、疾病活动度以及治疗方案相较上次的调整情况。':'从现有随访数据看，可以从疾病活动度趋势、持续异常指标和历次用药调整三个维度梳理。'}\n\n这是前端交互演示；接入 AI 接口后，这里会根据患者真实结构化数据生成回答，并支持连续追问。`;chat.scrollTop=chat.scrollHeight;},650);
  };
  document.getElementById('ai-drawer-backdrop').classList.add('open');drawer.classList.add('open');document.body.classList.add('ai-drawer-open');
  setTimeout(()=>drawer.querySelector('#ai-input').focus(),220);
};
window.closeAIChat=function(){const d=document.getElementById('ai-assistant-drawer'),b=document.getElementById('ai-drawer-backdrop');if(d)d.classList.remove('open');if(b)b.classList.remove('open');document.body.classList.remove('ai-drawer-open','ai-drawer-wide');};
