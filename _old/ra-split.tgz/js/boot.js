"use strict";window.addEventListener('error',()=>{const n=document.getElementById('app-load-status');if(n){n.hidden=false;n.textContent='交互加载异常，请确认 css、js、img 目录与页面文件一起保存。'}});
